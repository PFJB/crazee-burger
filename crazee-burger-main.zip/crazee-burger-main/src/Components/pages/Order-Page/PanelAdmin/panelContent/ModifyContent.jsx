export default function ModifyContent() {
  return (
    <div>ModifyProduct</div>
  )
}

